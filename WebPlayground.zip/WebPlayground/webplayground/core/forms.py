from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import*

class UserCreationFormWithEmail(UserCreationForm):
    email = forms.EmailField(required=True, help_text="Campo requerido para el registro 254 caracteres")

    class Meta:
        model = User
        fields = ("username", "email", "password1", "password2" )



class ProfileForm(forms.ModelForm):
    class Meta: Profile
    fields = ['avatar','bio','link']
    widgets = {

                 'avatar': forms.ClearableFileInput(attrs={'class':'form-control-file mt-3'}),
                 'bio': forms.Textarea(attrs={'class':'form-control-file mt-3'}),
                 'link': forms.URLInput(attrs={'class':'form-control-file mt-3'}),


                # 'link': forms.URLField(attrs={'class':'form-control-file mt-3'}),

                 #'bio': forms.Textarea(attrs={'class':'form-control-file mt-3', 'rows':3, 'placeholder': 'Biografia' }),
                 #'link': forms.URLField(attrs={'class':'form-control-file mt-3', 'placeholder': 'Link' }),

       #'avatar': forms.ClearableFileInput(attrs={'class':'form-control-file mt-3'}),
   

       # 
       # '

    #  'avatar' = forms.FileField(widget=forms.FileInput(attrs={'class': 'rounded_list'}))


    }   
        

    
class AreaForm(forms.ModelForm):
     class Meta:
        model = Area
    
        fields = ["nombre", "imagen", "descripcion"]

        widgets = {

             "nombre": forms.TextInput(attrs={'class':'form-control', 'placeholder': 'Digite el área'}),
             "imagen": forms.FileInput(attrs={'class':'form-control'}),
             "descripcion": forms.Textarea(attrs={'class':'form-control'}),
           

        }

