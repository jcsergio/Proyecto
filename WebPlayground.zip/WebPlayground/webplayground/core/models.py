from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import m2m_changed

from django.dispatch import receiver
from django.db.models.signals import post_save
from django.db.models.signals import m2m_changed

def custom_upload_to(instance, filename):
    old_instance = Profile.objects.get(pk=instance.pk)
    old_instance.avatar.delete()
    return 'profiles/' + filename

# Create your models here.
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    avatar = models.ImageField(upload_to=custom_upload_to, null=True, blank=True)
    bio = models.TextField(null=True, blank=True)
    link = models.URLField(max_length=200, null=True, blank=True)

    class Meta:
        ordering = ['user__username']

    
    def __str__(self):
        return self.user

@receiver(post_save, sender=User)
def ensure_profile_exits(sender, instance, **kwargs):
    if kwargs.get('created', False):
        Profile.objects.get_or_create(user=instance)
        print("Se acaba de crear un usuario y su perfil esta enlazadado")


# Chata (data) ------------------------------------------------------------------------------
'''
class Message(models.Model):
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sender')
    receiver = models.ForeignKey(User, on_delete=models.CASCADE, related_name='receiver')
    message = models.CharField(max_length=1200)
    timestamp = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

    def __str__(self):
        return self.message

    class Meta:
        ordering = ('timestamp',)

'''
# New Version (data) ---------------------------------------------------------------------------

'''class Message(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created']

'''

####---------------------------------------------------------------------------------------------->

class Area(models.Model):
    id = models.AutoField(primary_key= True)
    nombre = models.CharField('Event Name', max_length= 200)
    imagen = models.ImageField(upload_to='uploads', null=True, blank=True)
    descripcion = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.nombre

    

