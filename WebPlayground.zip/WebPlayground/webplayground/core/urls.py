from django.urls import path
from . import views
from .views import PlaygroundView, SamplePageView, SignUpView, ProfileUpdate, ProfileList,  ProfileDetailView, ShowProfiles
urlpatterns = [
    path('', views.home, name="home"),
    path('about', views.about, name="about"),
    path('doctors', views.doctors, name="doctors"),
    path('news', views.news, name="news"),
   
    path('playground/', PlaygroundView.as_view(), name="playground"),
    path('sample/', SamplePageView.as_view(), name="sample"),
    

    path('sitio_adm', views.sitio_adm, name="sitio_adm"),
    path('adm_area', views.adm_area, name="adm_area"),
    path('add_area', views.add_area, name="add_area"),
    path('update_area/<id>', views.update_area, name="update_area"),
    path('delete_area/<id>', views.delete_area, name="delete_area"),


    path('bd_perfil', views.show_profiles, name="bd_perfil"),
    path('chat_profiles', views.chat_profiles, name="chat_profiles"),
    path('<username>/', ProfileDetailView.as_view(), name='detail'),
    path('ShowProfiles', ShowProfiles.as_view(), name="ShowProfiles"),

    
    path('register_admin', views.register_admin, name="register_admin"),
    path('adm_login', views.adm_login, name="adm_login"),
    path('new_user', views.new_user, name="new_user"),
    path('success_user', views.success_user, name="success_user"),



    path('adm_register', SignUpView.as_view(), name="adm_register"),
    #path('adm_profile', views.adm_profile, name="adm_profile"),
    path('adm_profile', ProfileUpdate.as_view(), name="adm_profile"),
    

    path('listado/', ProfileList.as_view(), name="listado"),

    path('test_chat', views.test_chat, name='test_chat'),
    path('data_chat', views.data_chat, name='data_chat'),


    path('adm_messenger', views.adm_messenger, name="adm_messenger"),
    


]