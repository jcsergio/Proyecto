from .models import *
from django.shortcuts import render, HttpResponse, redirect

from django.views.generic import CreateView

from django.contrib.auth.forms import UserCreationForm
from django.views.generic.base import TemplateView
from django.views.generic.edit import UpdateView
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
from django.urls import reverse_lazy
from django import forms
from .forms import ProfileForm, AreaForm
from django.shortcuts import get_object_or_404
from django.views.generic.detail import DetailView
from django.views.generic.list import ListView


#from .forms import UserCreationFormWithEmail



# Create your views here.
from django.shortcuts import render

def home(request):
    return render(request, "website/home.html")

def about(request):
    return render(request, "website/about.html")

def doctors(request):
    return render(request, "website/doctors.html")

def news(request):
    return render(request, "website/news.html")





@login_required
def adm_area(request):
    area_list = Area.objects.all()
    return render(request, 'sitio_adm/adm_area.html', {'area_list':area_list})

def add_area(request):
    if request.method == 'POST':
        form = AreaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('adm_area')
    else:
      form = AreaForm()
    return render(request, 'sitio_adm/add_area.html', {'form':form})

def update_area(request,id):
    area = Area.objects.get(pk=id)
    form = AreaForm(request.POST or None, instance=area)
    if form.is_valid():
       form.save()
       return redirect('adm_area')

    return render(request, 'sitio_adm/update_area.html', {'area':area, 'form':form})


def delete_area(request,id):
    area = Area.objects.get(pk=id)
    area.delete()
    return redirect('adm_area')





def adm_messenger(request):
    return render(request, "sitio_adm/adm_messenger.html")






@login_required
def sitio_adm(request):
    return render(request, "core/sitio_adm.html")







class PlaygroundView(TemplateView):
    template_name = "core/playground.html"

    def get(selft, request, *args, **kwargs):
        return render(request, selft.template_name, {'title':"Mi Super web Playground"})

class SamplePageView(TemplateView):
    template_name = "core/sample.html"



def register_admin(request):
    return render(request, "core/login.html")


def adm_login(request):
    return render(request, "accounts/login.html")


def adm_register(request):
    return render(request, "accounts/registration/register.html")


def success_user(request):
    return render(request, "core/success_user.html")




'''
class SignUpView(CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy('adm_login')
    template_name = 'core/new_user.html'
'''


def new_user(request):
    return render(request, "core/new_user.html")


class SignUpView(CreateView):
    form_class = UserCreationForm
    template_name = 'core/new_user.html'
    success_url = reverse_lazy('success_user')
    
   



   # def get_success_url(self):
    #    return reverse_lazy('accounts/login.html') + '?register'


@login_required
def adm_profile(request):
    return render(request, "sitio_adm/adm_profile.html")

'''
class ProfileUpdate(UpdateView):
    form_class = UserCreationForm
    template_name = 'sitio_adm/adm_profile.html'
'''


'''
@method_decorator(login_required, name='dispatch')
class ProfileUpdate(UpdateView):
      model = Profile
      form_class = ProfileForm
      success_url = reverse_lazy('adm_profile')
      template_name = 'sitio_adm/adm_profile.html'

      def get_object(self):
        profile, created = Profile.objects.get_or_create(user=self.request.user)
        return profile

'''

'''
@method_decorator(login_required, name='dispatch')
class ProfileUpdate(UpdateView):
      model = Profile
      form_class = ProfileForm
      #fields = ['avatar', 'bio', 'link']
      success_url = reverse_lazy('adm_profile')
      template_name = 'sitio_adm/adm_profile.html'

      def get_object(self):
        # Se debe recuperar el objeto a editar
        #return Profile.objects.get_or_create(user=self.request.user)
        profile, created = Profile.objects.get_or_create(user=self.request.user)
        return profile
'''


@method_decorator(login_required, name='dispatch')
class ProfileUpdate(UpdateView):
      model = Profile
      fields = ['avatar', 'bio', 'link']
      success_url = reverse_lazy('adm_profile')
      template_name = 'sitio_adm/adm_profile.html'

      def get_object(self):
        # Se debe recuperar el objeto a editar
        #return Profile.objects.get_or_create(user=self.request.user)
        profile, created = Profile.objects.get_or_create(user=self.request.user)
        return profile





class ProfileList(TemplateView):
    model = Profile
    template_name = "profiles/perfiles.html"



def show_profiles(request):
    profile_list = Profile.objects.all()
    return render(request, 'sitio_adm/bd_perfil.html', {'profile_list':profile_list})


@login_required
def chat_profiles(request):
    profile_list = Profile.objects.all()
    return render(request, 'sitio_adm/chat_profiles.html', {'profile_list':profile_list})




@method_decorator(login_required, name='dispatch')
class ShowProfiles(ListView):
    model = Profile
    template_name = 'sitio_adm/ShowProfiles.html'
    paginate_by = 10




@method_decorator(login_required, name='dispatch')
class ProfileDetailView(DetailView):
    model = Profile
    template_name = 'sitio_adm/temp_detalles.html'

    def get_object(self):
        return get_object_or_404(Profile, user__username=self.kwargs['username'])





def test_chat(request):
    return render(request, "chat/index.html")

def data_chat(request):
    return render(request, "chat/data_chat.html")


