from django.shortcuts import render, get_object_or_404, get_list_or_404, redirect
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse, reverse_lazy
from .models import Page
from .forms import PageForm

from django.contrib.admin.views.decorators import staff_member_required
from django.utils.decorators import method_decorator


class StaffRequiredMixim(object):
    """ 
      Este mixin requerirá que el usuario sea miembro del staff     
    """

    @method_decorator(staff_member_required)
    def dispatch(self, request, *args, **kwargs):
        #print (request.user)
        
        #if not request.user.is_staff:
         #   return redirect(reverse_lazy('admin:login'))
        return super(StaffRequiredMixim, self).dispatch(request, *args, **kwargs)


# Create your views here.
'''
    def pages(request):
    pages = get_list_or_404(Page)
    return render(request, 'pages/pages.html', {'pages':pages})
'''
class PageListView(ListView):
    model = Page

'''
def page(request, page_id, page_slug):
    page = get_object_or_404(Page, id=page_id)
    return render(request, 'pages/page.html', {'page':page})
'''

class PageDetailView(StaffRequiredMixim, DetailView):
    model = Page

'''
class PageCreate(CreateView):
    model = Page
    fields = ['title', 'content', 'order']


    def get_success_url(self):
        return reverse('pages:pages')


-------------------------------------------------


class PageCreate(CreateView):
    model = Page
    form_class = PageForm
    #fields = ['title', 'content', 'order']
    success_url = reverse_lazy('pages:pages')

    def dispatch(self, request, *args, **kwargs):
        #print (request.user)
        if not request.user.is_staff:
            return redirect(reverse_lazy('admin:login'))
        return super(PageCreate, self).dispatch(request, *args, **kwargs)


'''

@method_decorator(staff_member_required, name='dispatch')
class PageCreate(CreateView):
#class PageCreate(StaffRequiredMixim, CreateView):
    model = Page
    form_class = PageForm
    success_url = reverse_lazy('pages:pages')

@method_decorator(staff_member_required, name='dispatch')   
class PageUpdate(UpdateView):
#class PageUpdate(StaffRequiredMixim, UpdateView):    
    model = Page
    form_class = PageForm
    #fields = ['title', 'content', 'order']
    template_name_suffix = '_update_form'
    
    def get_success_url(self):
        return reverse_lazy('pages:update', args=[self.object.id]) + '?ok'

@method_decorator(staff_member_required, name='dispatch')   
class PageDelete(DeleteView):
#class PageDelete(StaffRequiredMixim, DeleteView):
    model = Page
    success_url = reverse_lazy('pages:pages')



